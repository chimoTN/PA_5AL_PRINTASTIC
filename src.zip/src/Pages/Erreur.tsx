const Erreur = () => {
  return (
    <div style={{ padding: '2rem', textAlign: 'center' }}>
      <h1>Oups, une erreur est survenue</h1>
      <p>Nous rencontrons un problème. Veuillez réessayer plus tard.</p>
    </div>
  );
};

export default Erreur;
